Thanks for downloading Escape a Tower!

In order to run the game properly, you'll need to extract the ZIP file first. In Windows, simply click on Extract All. In OS X, the ZIP file should automatically be extracted upon opening the file.

After that, to play the game, all you have to do is open game.htm. All the other files are assets that game.htm calls for while playing.

Enjoy!

COMPATIBLE BROWSERS (+ means "or higher"):
Internet Explorer 9+
Firefox 3.5+
Chrome 4+
Safari 4+ (Mobile: iOS 4.3+, iOS 6+ recommended)
Opera 10.50+
Javascript must be enabled.

COPYRIGHT NOTICE: Permission is granted to read and modify the game's source code for personal use, but selling the game and distributing modified versions of the game without the author's permission is prohibited.

CONTACT INFO: To send feedback, bug reports, or suggestions relating this game, leave a comment at the following URL.

http://slideshowgames.blogspot.com/2011/08/escape-tower-more-info.html