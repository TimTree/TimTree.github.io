Thanks for playing Escape a Tower!

If you downloaded the game , you'll need to extract the ZIP file in order for the game to run properly. In Windows, simply click on Extract All. In OS X, the ZIP file should automatically be extracted upon opening the file.

After that, to play the game, all you have to do is open Escape a Tower.html. All the other files are assets that are called for while playing.

Enjoy!

COMPATIBLE BROWSERS (+ means "or higher"):
Internet Explorer 9+*
Firefox 3.5+
Chrome 4+
Safari 4+ (Mobile: iOS 4.3+, iOS 6+ recommended)
Opera 10.50+
Javascript must be enabled.

*Internet Explorer currently has problems with local storage on the download version. If you want to play the download version, please use a different browser. 

COPYRIGHT NOTICE: Permission is granted to read and modify the game's source code for personal use, but selling the game and distributing modified versions of the game without the author's permission is prohibited.

CONTACT INFO: To send feedback, bug reports, or suggestions relating this game, leave a comment at the following URL.

http://slideshowgames.blogspot.com/2011/08/escape-tower-more-info.html