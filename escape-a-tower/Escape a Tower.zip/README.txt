Thanks for playing Escape a Tower!

If you downloaded the game , you'll need to extract the ZIP file so the game can run properly. In Windows, simply click on Extract All. In OS X, the ZIP file should automatically be extracted upon opening the file.

After that, to play the game, all you have to do is open Escape a Tower.html. All the other files are assets that are called for while playing. Don't move around any of the files, or else the game won't work the way it should.

Enjoy!

COMPATIBLE BROWSERS
Microsoft Edge*
Internet Explorer 8+*
Firefox 3.5+
Chrome 4+
Safari 4+ (Mobile: iOS 4+, iOS 6+ recommended)
Opera 10.50+
Javascript must be enabled.

*For save related reasons, the downloaded version does not work with these browsers.

COPYRIGHT NOTICE
This game is copyright (c) 2010-2014 Timothy Hsu. Permission is granted to read and modify the game's source code for personal use, but selling the game and/or distributing modified versions of the game without the author's permission are prohibited.

CONTACT INFO
To send feedback, bug reports, or suggestions relating this game, leave a comment at the following URL.

http://slideshowgames.blogspot.com/2011/08/escape-tower-more-info.html